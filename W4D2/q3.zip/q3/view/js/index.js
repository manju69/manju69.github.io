$(() => {
    var addedProduct=[];
    const sucess = (resData)=>{
        $('#message').html = "Product added";
        addedProduct = resData;
        console.log(resData);
    };

    $("#productAdd").click(() => {
        console.log("kldfja");
        $.post({
            url: "/addToCart",
            id: $('#id').val(),
            contentType: "application/json; charset=utf-8"
        }).done(sucess)
            .fail();
        return false;
    });
});