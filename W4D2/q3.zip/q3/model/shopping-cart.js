module.exports = class ShoppingCart {
    static products = [];

    static addToCart(product) {
    		let index = -1;
    		for(let i = 0; i< ShoppingCart.products.length; i++){
        	if(ShoppingCart.products[i].id === product.id){
          	index = i;
            break;
            }
      	}
        if(index>=0){
        	ShoppingCart.products[index].quantity = ShoppingCart.products[index].quantity + 1;
        }
        else{
        	ShoppingCart.products.push(product);
        }
        
    }

    static getProducts() {
        return { products: ShoppingCart.products };
    }

}

